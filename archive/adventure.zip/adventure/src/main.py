# main.py
# this just runs the engine, nothing else
from engine import Engine

if __name__ == '__main__':
    e = Engine()
    e.run()
    