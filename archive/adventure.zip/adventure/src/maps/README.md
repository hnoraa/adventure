# maps
Maps were created with Tiled.

Current map: overworld_2.png

## TMX files
- overworld_1.tmx: test overworld, very basic, one layer
- overworld_2.tmx: 'island' like, has a layer for world objects (water and stone) and a layer for the main player. The objects layer helps with collision detection in the world itself (ex: can't walk on water)

## Tilesets
- tile_set_test_1.png: used in overworld_1.tmx, overworld_2.tmx. This is the main 'land' type tile images.
