# main.py
# entry point into the game
from game import Game

if __name__ == '__main__':
    g = Game()
    g.run()
