from tests import *

if __name__ == '__main__':
    g = T_playerSprite()
    g.loop()