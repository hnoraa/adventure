# fonts
FSANS = 'Arial'
FSERIF = 'Times New Roman'
FMONO = 'Courier New'
FCUST = 'retganon.ttf'

# sizes
FXXS = 10
FXSM = 12
FSML = 14
FMED = 16
FLRG = 20
FXLG = 24
FXL = 42
FXXL = 72
