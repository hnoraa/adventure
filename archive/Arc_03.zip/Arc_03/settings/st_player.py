import pygame

# player settings
PLAYER_SPEED = 300
PLAYER_SIZE = 32
PLAYER_HIT_RECT = pygame.Rect(0, 0, 35, 35)
VEL_FACTOR = 0.7071
PLAYER_SPRITE = 'catSpriteSheet1.png'
