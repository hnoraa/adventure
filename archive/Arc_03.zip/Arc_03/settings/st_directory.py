# subdirectories
IMG_DIR = '../res/imgs'
MAP_DIR = '../res/maps'
FONT_DIR = '../res/fonts'
