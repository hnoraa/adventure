# game settings
WIDTH = 800
HEIGHT = 600
FPS = 60
CLOCK_TICK = 1000
TITLE = "Adventure"
SUBTITLE = "Game"
