Font: Return of Ganon Font
Source: https://www.1001fonts.com/return-of-ganon-font.html